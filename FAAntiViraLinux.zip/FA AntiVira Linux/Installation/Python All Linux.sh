#!/bin/bash

# Versuche, den Standardwebbrowser zu öffnen und zur Python-Website zu navigieren
if command -v xdg-open >/dev/null 2>&1; then
    xdg-open "https://www.python.org/"
elif command -v gnome-open >/dev/null 2>&1; then
    gnome-open "https://www.python.org/"
elif command -v x-www-browser >/dev/null 2>&1; then
    x-www-browser "https://www.python.org/"
elif command -v open >/dev/null 2>&1; then
    open "https://www.python.org/"
else
    echo "Could not find a suitable command to open the web browser."
    exit 1
fi

