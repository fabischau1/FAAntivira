#!/bin/bash

echo "File Path:"
read FILE_PATH

if [ ! -f "$FILE_PATH" ]; then
    echo "File Does Not Exist."
    read -p "Press Enter to continue..."
    exit 1
fi

sha256sum "$FILE_PATH" > FAtemp.txt
sleep 3
chmod +x ./FAhashshower.sh
./FAhashshower.sh &
read -p "Press Enter to continue..."
rm FAtemp.txt
