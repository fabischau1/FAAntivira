#!/bin/bash

echo "Please don't put the https:// or the http:// in front of the link or the scanner will get confused and may not work properly."
echo "Please type an URL like this example.com:"
read -r userInput

if grep -q "$userInput" "FAurlDataBank.txt"; then
    echo "FA DataBank flagged this URL: \"$userInput\" as malicious."
else
    echo "FA DataBank flagged this URL: \"$userInput\" as probably safe, or the data bank doesn't include this URL, or you didn't follow the instructions. For better instructions, look at info."
fi

read -p "Press Enter to continue..."
