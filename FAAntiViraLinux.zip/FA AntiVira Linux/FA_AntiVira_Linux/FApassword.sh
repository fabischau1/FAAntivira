#!/bin/bash

echo "Generating a password..."

characters="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789,.<>?~"
passwordLength=30
password=""

for (( i=1; i<=passwordLength; i++ )); do
    randomIndex=$(( RANDOM % 94 ))
    char="${characters:randomIndex:1}"
    password="${password}${char}"
done

echo "Your Generated Password Is: $password"
read -p "Press Enter to continue..."

