#!/bin/bash

echo "Please Type In The Path Of The File You Want To Kill: "
read -r filepath

for (( i=1; i<=20000; i++ )); do
    echo "This File Was Overwritten By FA AntiVira $i Times" > "$filepath"
done

rm -f "$filepath"
echo "File Killed."
echo "File Was Permanently Deleted And Overwritten 20000 Times"
read -p "Press Enter to continue..."
