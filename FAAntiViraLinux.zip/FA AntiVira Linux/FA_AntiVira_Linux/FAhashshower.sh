#!/bin/bash

echo "File Path:"
read FILE_PATH

if [ ! -f "$FILE_PATH" ]; then
    echo "File Does Not Exist."
    read -p "Press Enter to continue..."
    exit 1
fi

sha256sum "$FILE_PATH" > FAtemp.txt
sleep 3

# Lesen der zweiten Zeile aus FAtemp.txt und Überprüfen in FAMalHashDatabase.txt
LINE_NUM=0
while IFS= read -r LINE; do
    ((LINE_NUM++))
    if [ $LINE_NUM -eq 2 ]; then
        grep -i "$LINE" "FAMalHashDatabase.txt" > /dev/null
        if [ $? -eq 0 ]; then
            echo "The File Hash is: $LINE"
            echo "Malware Detected"
            echo "Date: $(date) Time: $(date +%T) Result: Malware found" >> "FA_File_Scan_Log.txt"
            color 04  # Farbe rot (falls benötigt)
        else
            echo "The File Hash is: $LINE"
            echo "No Malware found"
            echo "Date: $(date) Time: $(date +%T) Result: No Malware found" >> "FA_File_Scan_Log.txt"
            color 0a  # Farbe grün (falls benötigt)
        fi
        break
    fi
done < FAtemp.txt

rm FAtemp.txt
read -p "Press Enter to continue..."
exit 0
