#!/bin/bash

echo "Please Choose an Action and Type In the number of the action you want to execute:"
echo "1 = Help"
echo "2 = URL Scan"
echo "3 = Single File Scan"
echo "4 = Delete A File In This Path"
echo "5 = Delete A File In A Specific Path"
echo "6 = Generate A Password"
echo "7 = Open Hash Database"
echo "8 = Open URL Database"
echo "9 = Open File Scan Log"
echo "10 = Virus Total Hash Scan"
echo "11 = Find Out The Hash Of A File"
echo "12 = Find Out Scan If A File Is Legit"
read -r choice

case $choice in
    1)
        less help.txt
        ;;
    2)
        ./FA_URLscan.sh
        ;;
    3)
        ./FAfilescan.sh
        ;;
    4)
        ./FAMalDelFiNS.sh
        ;;
    5)
        ./FAMalDelFiS.sh
        ;;
    6)
        ./FApassword.sh
        ;;
    7)
        less FAMalHashDatabase.txt
        ;;
    8)
        less FAurlDataBank.txt
        ;;
	9)
        less FA_File_Scan_Log.txt
        ;;
	10)
        ./VTR.py
        ;;
	11)
        ./FAhashc.sh
        ;;
	12)
        ./FAcertCheck.sh
        ;;
    *)
        echo "Please Choose A Number Between 1 and 8 Depending on the Action you want to execute"
        ;;
es

