import requests

api_key = '' # <- ENTER YOUR API KEY HERE BETWEEN ''
file_hash = input("Enter the SHA256 hash of the file you want to check: ")

url = f'https://www.virustotal.com/api/v3/files/{file_hash}'

headers = {
    'x-apikey': api_key
}

response = requests.get(url, headers=headers)

if response.status_code == 200:
    data = response.json()
    if 'data' in data:  # Check if data exists in the response
        file_info = data['data']['attributes']['last_analysis_results']
        print("File metadata:")
        print("SHA256:", data['data']['id'])
        print("File name:", data['data']['attributes']['names'][0])
        
        # Check if 'total' field exists in last_analysis_stats
        if 'last_analysis_stats' in data['data']['attributes']:
            print("Number of engines detected:", data['data']['attributes']['last_analysis_stats'].get('total', 'N/A'))
        else:
            print("Number of engines detected: N/A")
        
        print("Last analysis results:")
        for engine, result in file_info.items():
            print(f"{engine}: {result['category']} - {result['result']}")
    else:
        print("File not found in VirusTotal database.")
else:
    print("Unexpected error occurred. Status code:", response.status_code)

# Pause at the end
input("Press Enter to exit...")
