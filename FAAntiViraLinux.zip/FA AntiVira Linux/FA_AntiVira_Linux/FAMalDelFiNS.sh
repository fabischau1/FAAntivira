#!/bin/bash

echo "Please Type In The Filename Of The File You Want To Kill (without path): "
read -r filename

# Kombinieren des Dateinamens mit dem aktuellen Verzeichnis
filepath="./$filename"

for (( i=1; i<=20000; i++ )); do
    echo "This File Was Overwritten By FA AntiVira $i Times" > "$filepath"
done

rm -f "$filepath"
echo "File Killed."
echo "File '$filename' Was Permanently Deleted And Overwritten 20000 Times"
read -p "Press Enter to continue..."
