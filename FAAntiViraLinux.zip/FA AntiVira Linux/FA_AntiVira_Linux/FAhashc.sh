#!/bin/bash

echo "Filename:"
read -r filename

if [[ -f "$filename" ]]; then
    echo "SHA256-Hash der Datei $filename:"
    sha256sum "$filename"
else
    echo "File '$filename' Does Not Ecsist in This Path."
fi

read -p "Press any Key to Continue..."
