#!/bin/bash
echo File Certifikat Checker
echo You can only scan a file that is inside this folder
echo "File Name:"
read -r filename

if [[ -f "$filename" ]]; then
    echo "Checking $filename..."
    
    if gpg --verify "$filename" 2>/dev/null; then
        echo "File is Legit."
    else
        echo "File May Be Dangerous."
    fi
else
    echo "File '$filename' Does Not Ecsist In This Folder."
fi

read -p "Press any key to continue..."
